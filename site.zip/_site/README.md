Source Code for xebia studio web site

This runs with jekyll.

* install [jekyll](https://github.com/mojombo/jekyll/wiki/install)
* checkout code
* run jekyll --server
* open your browser on http://localhost:4000

